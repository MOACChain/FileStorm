#!/bin/bash
echo "Starting FileStorm SCS--"

IPFS_PATH=~/.ipfs nohup ipfs daemon > ipfs.out 2>&1 &
echo "IPFS Daemon started."

nohup redis-server --port 6379 > ipfs.out 2>&1 &
echo "Redis Server started. "

nohup ./ipfs_monkey --listen-host-port 127.0.0.1:18080 --redis-host-port 127.0.0.1:6379 --ipfs-host-port 127.0.0.1:5001 > ipfs.out 2>&1 &
echo "IPFS Monkey started."

nohup ./scsserver --rpcaddr 127.0.0.1 --rpcport 50068 --rpc2 --rpccorsdomain "*" --verbosity 3 > scs.out 2>&1 &
echo "SCS started."

